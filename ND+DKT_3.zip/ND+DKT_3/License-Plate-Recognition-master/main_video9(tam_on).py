import cv2
import time
from collections import Counter
from src.lp_recognition import E2E

# Khởi tạo camera
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Không thể mở camera!")
    exit()

# Load model nhận diện biển số
model = E2E()

def capture_plate():
    """Quét biển số trong 3 giây và chọn biển số phổ biến nhất."""
    plate_records = []
    start_time = time.time()
    scan_duration = 3

    print("🚗 Hệ thống đang quét biển số...")
    while time.time() - start_time < scan_duration:
        ret, frame = cap.read()
        if not ret:
            print("Không thể nhận frame từ camera!")
            return None

        # Dự đoán biển số xe
        _, plate_text = model.predict(frame)
        if plate_text:
            plate_records.extend(plate_text)

        # Hiển thị camera
        cv2.imshow('Camera', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            cap.release()
            cv2.destroyAllWindows()
            exit()

    if not plate_records:
        print("🚫 Không phát hiện biển số xe!")
        return None

    # Đếm số lần xuất hiện của từng biển số
    plate_counts = Counter(plate_records)
    most_common_plate, count = plate_counts.most_common(1)[0]
    if count >= 3:
        return most_common_plate
    else:
        print(f"⚠️ Biển số {most_common_plate} chỉ xuất hiện {count} lần!")
        return None

def open_gate(plate_number):
    """Giả lập mở cổng khi xác nhận biển số hợp lệ."""
    print(f"✅ Xác nhận biển số: {plate_number}. Mở cổng 🚦...")
    time.sleep(2)
    print("🔄 Hệ thống sẵn sàng cho xe tiếp theo!")

while True:
    plate_number = capture_plate()
    if plate_number:
        open_gate(plate_number)
    print("⏳ Chờ xe tiếp theo...")
    time.sleep(1)