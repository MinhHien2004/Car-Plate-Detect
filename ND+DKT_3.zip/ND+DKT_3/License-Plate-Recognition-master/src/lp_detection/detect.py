from ultralytics import YOLO
import cv2
# Tắt log
import logging
logging.getLogger('ultralytics').setLevel(logging.CRITICAL)
class detectNumberPlate:
    def __init__(self, weight_path, threshold=0.5):
        self.model = YOLO(weight_path)
        self.threshold = threshold

    def detect(self, image):
        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = self.model(rgb_image)[0]
        coordinates = []
        for box in results.boxes:
            if box.conf.item() >= self.threshold:
                x_min, y_min, x_max, y_max = map(int, box.xyxy[0].tolist())
                coordinates.append((x_min, y_min, x_max - x_min, y_max - y_min))
        return coordinates