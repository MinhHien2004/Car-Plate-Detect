# from tensorflow.keras.models import Sequential
# from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout

# class CNN_Model:
#     def __init__(self, trainable=True):
#         self.model = self._build_model()

#     def _build_model(self):
#         model = Sequential([
#             Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
#             MaxPooling2D((2, 2)),
#             Flatten(),
#             Dense(128, activation='relu'),
#             Dropout(0.5),
#             Dense(32, activation='softmax')
#         ])
#         return model

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout

class CNN_Model:
    def __init__(self, trainable=True):
        self.model = self._build_model()

    def _build_model(self):
        # CNN model
        model = Sequential()
        model.add(Conv2D(32, (3, 3), padding='same', activation='relu', input_shape=(28, 28, 1)))
        model.add(Conv2D(32, (3, 3), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Dropout(0.25))

        model.add(Conv2D(64, (3, 3), padding='same', activation='relu'))
        model.add(Conv2D(64, (3, 3), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Dropout(0.25))

        model.add(Conv2D(64, (3, 3), padding='same', activation='relu'))
        model.add(Conv2D(64, (3, 3), activation='relu'))
        model.add(MaxPooling2D(pool_size=(2, 2)))
        model.add(Dropout(0.25))

        model.add(Flatten())
        model.add(Dense(512, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(32, activation='softmax'))

        return model