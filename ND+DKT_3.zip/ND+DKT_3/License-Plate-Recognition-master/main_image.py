import cv2
from collections import Counter
from src.lp_recognition import E2E
import time

# Load model nhận diện biển số
model = E2E()

def capture_plate_from_image(image_path):
    frame = cv2.imread(image_path)
    if frame is None:
        print("❌ Không thể đọc ảnh từ đường dẫn đã cho!")
        return None

    print("🖼️ Hệ thống đang nhận diện biển số từ ảnh...")

    # Dự đoán biển số xe
    _, plate_text = model.predict2(frame)
    if not plate_text:
        print("🚫 Không phát hiện biển số xe!")
        return None

    print(f"✅ Biển số phát hiện: {plate_text}")
    return plate_text


def open_gate(plate_number):
    """Giả lập mở cổng khi xác nhận biển số hợp lệ."""
    print(f"✅ Xác nhận biển số: {plate_number}. Mở cổng 🚦...")
    time.sleep(2)
    print("🔄 Hệ thống sẵn sàng cho xe tiếp theo!")

# Ví dụ sử dụng:
if __name__ == "__main__":
    image_path = r"D:\python\ND+DKT_3\xe1.jpg"  # ← Thay đổi thành đường dẫn ảnh của bạn
    plate_number = capture_plate_from_image(image_path)
    if plate_number:
        open_gate(plate_number)
