import cv2
import numpy as np
from ultralytics import YOLO
import pytesseract
import re
import os
import time
import logging
from collections import Counter
import threading

# ========== HỆ THỐNG CẤU HÌNH ==========
os.environ["YOLO_VERBOSE"] = "False"
logging.getLogger('ultralytics').setLevel(logging.WARNING)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'


class LicensePlateDetector:
    def __init__(self, model_path):
        # Tối ưu hóa mô hình YOLO
        self.yolo_model = YOLO(model_path)
        self.yolo_model.overrides['imgsz'] = 256  # Giảm độ phân giải để tăng tốc độ

        # Cấu hình OCR linh hoạt
        self.tesseract_config = {
            'single': r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789ABCDEFGHKLMNPRSTUVXYZ-.',
            'double': r'--oem 3 --psm 6 -c tesseract_char_whitelist=0123456789ABCDEFGHKLMNPRSTUVXYZ-.'
        }

        # Trạng thái phát hiện và chụp ảnh
        self.state = "WAITING"  # WAITING, CAPTURING, PROCESSING
        self.captured_frames = []
        self.capture_count = 0
        self.required_captures = 10
        self.processed_frame = None
        self.last_vehicle_time = 0
        self.vehicle_detected = False
        self.cooldown_period = 5  # Thời gian chờ (giây) trước khi phát hiện xe mới

        # Khóa đồng bộ hóa
        self.lock = threading.Lock()

    def _is_valid_vietnam_plate(self, text):
        """Kiểm tra định dạng biển số Việt Nam"""
        patterns = [
            r'^\d{2}[A-Z]-?\d{3,5}\.?\d{0,2}$',  # 1 dòng: 59A-12345 hoặc 59A-123.45
            r'^\d{2}[A-Z]\s+\d{4,5}$',  # 2 dòng: 59A 12345
            r'^\d{2}[A-Z]-\d{3}\.\d{2}$'  # Định dạng có dấu chấm: 59A-123.45
        ]
        text = text.replace('\n', ' ').strip()
        return any(re.match(p, text) for p in patterns)

    def _preprocess_plate(self, plate_img, is_double_line):
        """Tiền xử lý ảnh biển số"""
        if plate_img is None or plate_img.size == 0:
            return None

        gray = cv2.cvtColor(plate_img, cv2.COLOR_BGR2GRAY)

        # Thêm các kỹ thuật làm rõ
        if is_double_line:
            gray = cv2.GaussianBlur(gray, (3, 3), 0)
            gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        else:
            gray = cv2.equalizeHist(gray)

        return gray

    def _detect_vehicles(self, frame):
        """Phát hiện xe trong khung hình"""
        results = self.yolo_model.predict(
            frame,
            verbose=False,
            conf=0.5,
            classes=[0],  # Giả sử class 0 là biển số xe
            augment=False
        )

        return len(results[0].boxes) > 0

    def _analyze_frame(self, frame):
        """Phân tích một khung hình để tìm biển số"""
        results = self.yolo_model.predict(
            frame,
            verbose=False,
            conf=0.7,
            iou=0.4,
            classes=[0],
            augment=False
        )

        output_frame = frame.copy()
        detections = []

        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = box.conf[0].item()

                plate_img = frame[y1:y2, x1:x2]
                if plate_img.size == 0:
                    continue

                is_double_line = (x2 - x1) / (y2 - y1) < 2.0

                processed_plate = self._preprocess_plate(plate_img, is_double_line)
                if processed_plate is None:
                    continue

                try:
                    text = pytesseract.image_to_string(
                        processed_plate,
                        config=self.tesseract_config['double' if is_double_line else 'single'],
                        lang='eng'
                    ).strip().upper()

                    text = re.sub(r'[^0-9A-Z-.]', '', text)

                    if self._is_valid_vietnam_plate(text):
                        detections.append((text, conf, (x1, y1, x2, y2)))
                        # Vẽ hình chữ nhật và hiển thị văn bản
                        cv2.rectangle(output_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        cv2.putText(output_frame, f"{text} ({conf:.2f})", (x1, y1 - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                except Exception as e:
                    print(f"OCR Error: {e}")
                    continue

        return output_frame, detections

    def _process_captures(self):
        """Xử lý 3 ảnh đã chụp để trích xuất biển số tin cậy nhất"""
        all_texts = []
        all_confidences = {}

        # Phân tích từng ảnh đã chụp
        for i, frame in enumerate(self.captured_frames):
            _, detections = self._analyze_frame(frame)
            print(f"Frame {i + 1}: Phát hiện {len(detections)} biển số")

            for text, conf, _ in detections:
                all_texts.append(text)
                if text in all_confidences:
                    all_confidences[text].append(conf)
                else:
                    all_confidences[text] = [conf]

        # Tìm biển số xuất hiện nhiều nhất
        if all_texts:
            counter = Counter(all_texts)
            most_common = counter.most_common(1)[0]
            plate_text = most_common[0]
            occurrences = most_common[1]

            # Tính độ tin cậy trung bình
            avg_conf = np.mean(all_confidences[plate_text])

            print(
                f"\n>> KẾT QUẢ BIỂN SỐ: {plate_text} | ĐỘ CHÍNH XÁC: {avg_conf:.2%} | XH: {occurrences}/{self.required_captures} <<\n")
            return plate_text, avg_conf
        else:
            print("\n>> KHÔNG PHÁT HIỆN ĐƯỢC BIỂN SỐ HỢP LỆ <<\n")
            return None, 0

    def update_frame(self, frame):
        """Cập nhật và xử lý frame mới"""
        current_time = time.time()
        display_frame = frame.copy()

        # Kiểm tra trạng thái hiện tại
        if self.state == "WAITING":
            # Kiểm tra xem có xe xuất hiện không
            vehicle_present = self._detect_vehicles(frame)

            # Hiển thị trạng thái
            cv2.putText(display_frame, "DANG CHO XE...", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

            # Nếu phát hiện xe và đã qua thời gian chờ
            if vehicle_present and (current_time - self.last_vehicle_time > self.cooldown_period):
                print("Phát hiện xe - Bắt đầu chụp ảnh")
                self.state = "CAPTURING"
                self.captured_frames = []
                self.capture_count = 0

        elif self.state == "CAPTURING":
            # Hiển thị số lượng ảnh đã chụp
            cv2.putText(display_frame, f"DANG CHUP ANH: {self.capture_count + 1}/{self.required_captures}",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            # Thêm khoảng thời gian giữa các lần chụp
            if current_time - self.last_vehicle_time > 0.5:  # 0.5 giây giữa các lần chụp
                # Chụp ảnh hiện tại
                self.captured_frames.append(frame.copy())
                self.capture_count += 1
                self.last_vehicle_time = current_time

                print(f"Đã chụp ảnh {self.capture_count}/{self.required_captures}")

                # Kiểm tra xem đã chụp đủ số lượng ảnh chưa
                if self.capture_count >= self.required_captures:
                    print("Đã chụp đủ ảnh - Bắt đầu xử lý")
                    self.state = "PROCESSING"

        elif self.state == "PROCESSING":
            # Hiển thị thông báo đang xử lý
            cv2.putText(display_frame, "DANG XU LY...", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

            # Xử lý các ảnh đã chụp
            plate_text, conf = self._process_captures()

            # Hiển thị kết quả trên khung hình
            if plate_text:
                cv2.putText(display_frame, f"BIEN SO: {plate_text}", (10, 70),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.putText(display_frame, f"DO CHINH XAC: {conf:.2%}", (10, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            # Quay lại trạng thái chờ và đặt thời gian chờ
            self.state = "WAITING"
            self.last_vehicle_time = current_time

        return display_frame


def main():
    # Cấu hình capture card
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    # Đường dẫn model YOLO - hãy thay đổi đường dẫn này cho phù hợp
    model_path = 'D:/python/ND+DKT_3/License-Plate-Recognition-master/src/weights/best.pt'

    detector = LicensePlateDetector(model_path)

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            display_frame = detector.update_frame(frame)
            cv2.imshow('Nhan Dien Bien So Xe Viet Nam', display_frame)

            if cv2.waitKey(1) == ord('q'):
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()